This file contains Python scripts for working with NEON data.

gdal_merge.py - is a standard GDAL script and comes with your GDAL download. It
included here only for convenience as the tutorials are written assuming that is
in your working directory.

plot_spatial_array.py - written by Bridget Hass. 2018-07-09

raster2array.py - written by Bridget Hass. 2018-07-09
