#!/opt/anaconda1anaconda2anaconda3/bin/python
# EASY-INSTALL-SCRIPT: 'GDAL==2.2.4','gdal_merge.py'
__requires__ = 'GDAL==2.2.4'
__import__('pkg_resources').run_script('GDAL==2.2.4', 'gdal_merge.py')
